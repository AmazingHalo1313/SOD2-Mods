# Realistic Vehicle Trunk Storage

This Mod changes the trunk storage capacity of every regular vehicle in State of Decay 2. 

*Independence DLC Cars included.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 1.0.0 

## Authors

* **ColDisco** - *Creator*

## Acknowledgments

* Special thanks to Bulbasaur for getting me into this!

## Discord
https://discord.gg/emhxg5d
