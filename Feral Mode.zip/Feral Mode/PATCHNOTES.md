## Patch Notes

| **Version** | **Notes** |
| :---: | :---: |
| 2.0.0 | Updated to work on latest SOD2 patch |
