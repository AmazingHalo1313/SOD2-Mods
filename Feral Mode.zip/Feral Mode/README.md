# Feral Mode

This mod changes zombie spawns to ferals. 

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 2.0.0 

## Authors

* **TylerY86** - *Original Creator*
* **XTheFallen0neX** - *Updater*

## Discord
https://discord.gg/emhxg5d