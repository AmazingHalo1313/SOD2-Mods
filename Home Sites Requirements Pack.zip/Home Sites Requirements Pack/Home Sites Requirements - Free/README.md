# Home Sites Requirements - Free

This mod changes influence cost and population requirement for home sites to free.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 1.0.0 

## Authors

* **Andrei Vasilevski** - *Creator*

## Acknowledgments

* Hat tip to the guys/girls at State Of Decay 2 Modding Discord.

## Discord
https://discord.gg/emhxg5d