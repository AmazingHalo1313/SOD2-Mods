# Home Sites Requirements Pack

This mod changes influence cost and population requirement for home sites. Half or free versions available.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder of the mod you want into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 1.0.0 

## Issues/Warnings

If you're seeing an issue where a base is named incorrectly, navigate to "%LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\Cooked\UWP\StateofDecay2\Content\GameSystems\BaseManagement" and delete "Desktop.ini"

## Authors

* **Andrei Vasilevski** - *Creator*

## Acknowledgments

* Hat tip to the guys/girls at State Of Decay 2 Modding Discord.

## Discord
https://discord.gg/emhxg5d