# Max Prestige

Rewards you 65k prestige for beating the first wave, unlocking the 50k prestige achievement and maxing your available prestige.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 1.0.0 

## Authors

* **Heilos** - *Creator*

## Acknowledgments

* Hat tip to the guys/girls at State Of Decay 2 Modding Discord.

## Discord
https://discord.gg/emhxg5d
