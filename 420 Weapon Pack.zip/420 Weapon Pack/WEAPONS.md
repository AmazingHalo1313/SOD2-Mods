
| Weapon Type | Weapon Name |
| :---: | :---: |
| Weapon Type | Weapon Name |
