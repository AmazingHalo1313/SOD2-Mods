## Patch Notes

| **Version** | **Notes** |
| :---: | :---: |
| 1.0.0 | Dummy notes here. Please change when you patch the mod. |
