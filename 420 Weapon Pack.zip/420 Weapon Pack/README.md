# 420 Weapon Pack

Modified over 30 existing weapons. Use the Read Me file provided in download to see all the weapons modified with this. The guns feature increased stats, rapid fire, unlimited ammo, unlimited durability, no spread, and max quietness. The melee weapons feature increased stats, unlimited durability, and no stamina cost to swing them.  

*You must be using the specific weapons for it to take effect. (all listed in read me file) 

*This edits existing weapons doesn't add new ones!

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 2.3.0 

## Authors

* **Bulbasaur420** - *Creator*

## Acknowledgments

* Special thanks to everyone who has contributed in one way or another.

## Discord
https://discord.gg/emhxg5d
