# No Leadership Requirements - Facilities Only

Removes leader requirements for the 4 leadership facilities (Sniper Tower, Field Hospital, Trade Depot, and Armory).

Anyone can build them, but you still need a large slot.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 1.0.1 

## Authors

* **Andrei Vasilevski** - *Creator*

## Acknowledgments

* Hat tip to the guys/girls at State Of Decay 2 Modding Discord.
* Thanks to **Dadditude™™**  for his website's list.

## Discord

SOD2 Modding: https://discord.gg/emhxg5d

Andrei Vasilevski(#8122): https://discord.gg/K2Prg6h
