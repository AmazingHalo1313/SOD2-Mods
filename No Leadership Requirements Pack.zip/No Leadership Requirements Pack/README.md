# No Leadership Requirements Pack

This mod lets you remove leadership requirements from buildings. Facilities Only or Full versions available.

Facilities Only or Full version available.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder of the mod you want into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 1.0.1 

## Authors

* **Andrei Vasilevski** - *Creator*

## Acknowledgments

* Hat tip to the guys/girls at State Of Decay 2 Modding Discord.
* Thanks to **Dadditude™™**  for his website's list.

## Discord

SOD2 Modding: https://discord.gg/emhxg5d

Andrei Vasilevski(#8122): https://discord.gg/K2Prg6h
