# No More Woopsies

This mod stops survivors from destroying resources for no reason.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Paks folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 1.0.0 

## Authors

* **TylerY86** - *Creator*

## Discord
https://discord.gg/emhxg5d