## Patch Notes

| **Version** | **Notes** |
| :---: | :---: |
| 2.3.0 | Fixed any issues from updates breaking the mods |
