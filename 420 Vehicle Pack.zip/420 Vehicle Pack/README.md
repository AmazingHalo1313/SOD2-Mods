# 420 Vehicle Pack

This car pack enables super speed on all cars in the game with some cars being extremely fast. It also gives you unlimited fuel. (Host only unfortunately, the other two work being host or not). Thirdly, you should take no impact damage when running into objects (Mainly prevents car from blowing up when super speeding into things). 

Zombies can still damage your car. 

*Independence DLC Cars included.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 2.1.0 

## Authors

* **Bulbasaur420** - *Creator*

## Acknowledgments

* Special thanks to everyone who has contributed in one way or another.
* Shout out to Heilos for identifying the acceleration values.

## Discord
https://discord.gg/emhxg5d
