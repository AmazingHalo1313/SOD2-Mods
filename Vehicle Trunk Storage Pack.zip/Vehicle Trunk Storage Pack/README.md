# Vehicle Trunk Storage Pack

This Mod changes the trunk storage capacity of every vehicle in State of Decay 2. Realistic and Large versions available.

*DLC Cars included.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder of the mod you want into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

or

Go to the folder of the mod you want to install and double click the "Install.bat".

## Versioning

Version: 1.0.0 

## Authors

* **ColDisco** - *Original Creator (Vehicle Storage - Realistic)*
* **JDimensional** - *Edited into (Vehicle Storage - Large)*

## Acknowledgments

* Special thanks to Bulbasaur for getting me into this! (ColDisco)
* Special thanks to ColDisco for his original work with the Realistic Vehicle Storage Mod. (JDimensional)

## Discord
https://discord.gg/emhxg5d