# Vehicle Trunk Storage - Large

This Mod changes the trunk storage capacity of every vehicle in State of Decay 2 to x50.

*DLC Cars included.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

or

Double click the "Install.bat".

## Versioning

Version: 1.0.0 

## Authors

* **JDimensional** - *Creator*

## Acknowledgments

* Special thanks to ColDisco for his original work with the Realistic Vehicle Storage Mod.

## Discord
https://discord.gg/emhxg5d
