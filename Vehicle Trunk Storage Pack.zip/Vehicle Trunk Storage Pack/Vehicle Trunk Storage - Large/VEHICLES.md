| Vehicle Class | Vehicle Name | Trunk Slots |
| :---: | :---: | :---: |
| Coupe | Golf Cart | 50 |
| Coupe | Road Mangler |  50 |
| Coupe | Road Racer | 50 |
| Coupe | Road Racer MX | 50 |

| Hatchback | Brogan Rapscallion | 50 |
| Hatchback | Brogan Sport | 50 |
| Hatchback | Brogan Trekker | 50 |
| Hatchback | Hellion | 50 |
| Hatchback | Pyrohawk DLC1 | 50 |
| Hatchback | Survey Car | 50 |

| Musclecar | Maximilian |  50 |
| Musclecar | Mega Max | 50 |

| Offroad | Desperado | 50 |
| Offroad | Trail Beast | 50 |
| Offroad | Vagabond | 50 |

| RV | RV | 50 |

| Sedan | Impaler | 50 |
| Sedan | Kaiser | 50 |
| Sedan | Legendre | 50 |
| Sedan | Miragra | 50 |
| Sedan | Miragra NT | 50 |
| Sedan | Police Cruiser | 50 |
| Sedan | Royale | 50 |
| Sedan | Taxi | 50 |
| Sedan | Wichtia ES | 50 |

| SUV | Pilato | 50 |
| SUV | Pilato CR | 50 |
| SUV | Smashwagon | 50 |


| Truck | Big Boss | 50 |
| Truck | Burninator DLC1 | 50 |
| Truck | Military Truck | 50 |
| Truck | Norma | 50 |
| Truck | Rhames V | 50 |
| Truck | Utility Truck | 50 |
| Truck | Viking | 50 |
| Truck | Zedbuster | 50 |

| Van | Ambulance | 50 |
| Van | Cargo Van | 50 |
| Van | Meatwagon DLC1 | 50 |
| Van | News Van | 50 |
| Van | Passenger Van | 50 |
| Van | Repair Van | 50 |
| Van | Vandito | 50 |