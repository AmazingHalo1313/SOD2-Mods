## Patch Notes

| **Version** | **Notes** |
| :---: | :---: |
| 1.0.0 | Made into a pack type mod containing both Large and Realistic Trunk Storage.|
