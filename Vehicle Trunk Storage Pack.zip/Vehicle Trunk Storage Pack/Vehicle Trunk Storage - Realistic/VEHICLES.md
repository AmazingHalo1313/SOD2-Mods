
| Vehicle Class | Vehicle Name | Trunk Slots |
| :---: | :---: | :---: |
| Coupe | Road Mangler |  8 |
| Coupe | Road Racer | 6 |
| Coupe | Road Racer Mx | 6 |
| Hatchback | Brogan Rapscallion | 10 |
| Hatchback | Brogan Sport | 10 |
| Hatchback | Brogan Trekker | 12 |
| Hatchback | Hellion | 10 |
| Hatchback | Pyrohawk DLC1 | 12 |
| Hatchback | Survey Car | 10 |
| Musclecar | Maximilian |  8 |
| Musclecar | Mega Max | 6 |
| Offroad | Desperado | 12 |
| Offroad | Trail Beast | 10 |
| Offroad | Vagabond | 12 |
| Sedan | Impaler | 12 |
| Sedan | Kaiser | 12 |
| Sedan | Legendre | 12 |
| Sedan | Miragra | 12 |
| Sedan | Miragra NT | 12 |
| Sedan | Police Cruiser | 12 |
| Sedan | Royale | 13 |
| Sedan | Taxi | 12 |
| Sedan | Wichtia ES | 12 |
| SUV | Pilato | 1 8 |
| SUV | Pilato CR | 1 8 |
| SUV | Smashwagon | 1 8 |
| Truck | Big Boss | 24 |
| Truck | Burninator DLC1 | 24 |
| Truck | Military Truck | 24 |
| Truck | Norma | 24 |
| Truck | Rhames V | 24 |
| Truck | Utility Truck | 24 |
| Truck | Viking | 24 |
| Truck | Zedbuster | 24 |
| Van | Ambulance | 26 |
| Van | Cargo Van | 30 |
| Van | Meatwagon DLC1 | 30 |
| Van | News Van | 30 |
| Van | Passenger Van | 20 |
| Van | Repair Van | 30 |
| Van | Vandito | 30 |
