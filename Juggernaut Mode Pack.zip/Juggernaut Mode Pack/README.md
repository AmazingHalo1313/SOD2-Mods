# Juggernaut Mode Pack

This mod changes zombie spawns to juggernauts. Light or Heavy versions available.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder of the mod you want into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 4.2.0 

## Authors

* **Bulbasaur** - *Creator*

## Acknowledgments

* Special thanks to TylerY86, Toasty, and Andrei Vasilevski.

## Discord
https://discord.gg/emhxg5d