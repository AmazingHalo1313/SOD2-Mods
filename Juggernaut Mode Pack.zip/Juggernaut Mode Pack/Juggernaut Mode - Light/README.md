# Juggernaut Mode Light

This mod changes zombie spawns to all juggernauts.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 4.2.0 

## Authors

* **Bulbasaur** - *Creator*

## Acknowledgments

* Special thanks to TylerY86, Toasty, and Andrei Vasilevski.

## Discord
https://discord.gg/emhxg5d