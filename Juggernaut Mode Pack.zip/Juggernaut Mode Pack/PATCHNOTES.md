## Patch Notes

| **Version** | **Notes** |
| :---: | :---: |
| 4.2.0 | Updated Juggernaut mode as was previously broken from zedhunter update. |
