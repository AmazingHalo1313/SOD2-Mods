## Wave 1
| BML-40 |
M32 MGL |
B50FG |
Operators M4A1 |
RTX Piranha |
Katana Machete |

## Wave 2
| RTX Cyclone |
RTX Cyclone Tactical |
DEVGRU X12 Infiltrator |
MP5A2 Spec Ops |
RTX Rampart |
GSG-W |

## Wave 3
| Sweet Skull Sword |
Civilian Vector Carbine |
KendoShinai |
G18 Auto Custom |
Bastard of Belleau Wood |
MAC-V |
Faithful KSG |

## Wave 4
| M203 Standalone |
BML-40 |
M32 MGL |
B50FG |
930SPX |
