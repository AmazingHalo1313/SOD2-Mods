# Better Cleo Drops (Daybreak)

This mod gives you better Cleo drops in daybreak mode.

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

## Versioning

Version: 1.0.1 

## Authors/Contributors

* **XTheFallen0neX** - *Creator*
* **Bulbasaur** - *Contributor*

## Acknowledgments

* Special thinks to Bulbasaur.

## Discord
https://discord.gg/emhxg5d
