# Hard Mode 420

Pretty self explanatory, but this is Hard Mode for Sod 2. Basically all of the spawns of all zombies are cranked up. Use this at your own risk and Make sure to have a recent manual backup or backup from Community Editor to revert back to incase people die(which they more than likely will).

# Notes
Make sure youre not installing this with other zombie modifying mods. If you are, you will need to delete those in your Cooked folder before installing this otherwise problems could occur. 

## Getting Started

Start by extracting the zip file provided.

### Installing

Copy the Cooked folder of the mod you want into %LocalAppData%\Packages\Microsoft.Dayton_8wekyb3d8bbwe\LocalState\StateOfDecay2\Saved\

or

Double click the "Install.bat".

## Versioning

Version: 1.00 

## Authors

* **Bulbasaur** - *Creator*

## Acknowledgments

* Thanks to JDimensional.

## Discord
https://discord.gg/emhxg5d