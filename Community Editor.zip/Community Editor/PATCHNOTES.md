## Patch Notes

| **Version** | **Notes** |
| :---: | :---: |
| 1.1.2a | Some minor back end tweaks. |

| 1.1.3b | Removed some unnecessary data from the survivor editing tab. |
| 1.1.3b | Fixed the survivor revive button to work with the new save format. |
| 1.1.3b | Added in all the new item IDs up to version 6 of the game. |

| 1.1.3c | Fixed a typo causing item IDs to crash the editor. |
