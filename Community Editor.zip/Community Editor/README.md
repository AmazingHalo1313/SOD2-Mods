# Community Editor

Makes it possible to edit your community completely from community name to  resource amounts. Character traits and skills can be edited a long with weapon ammo amounts and durabilities and much more. See INFO.md for more.

## Getting Started

Start by extracting the zip file provided.

### How To

1. Run CommEdit.exe
2. Select a save detection method (Auto or Manual).
3. Select a community you want to edit.
4. Make any edits you like and be sure to save between each and every change just to be sure it saves.
5. Exit the app and open your game and load your save.
6. Enjoy your modded save like a boss.

## Versioning

Version: 1.1.2a 

## Notes/Info/Warnings

**Note:** DO NOT overwrite the old versions with new versions. DELETE old versions to avoid conflicting file issues

## Authors

* **Heilos** - *Creator*

## Acknowledgments

* Hat tip to the guys/girls at State Of Decay 2 Modding Discord.

## Discord
https://discord.gg/emhxg5d